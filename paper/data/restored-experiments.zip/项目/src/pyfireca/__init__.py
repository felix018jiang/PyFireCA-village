"""PyFireCA: extensible cellular automata for wildfire spread research."""

from pyfireca.arrival import (
    ConstantDirectionalSpreadRate,
    DirectionalSpreadRateProvider,
    StaticArrivalTimeSolver,
    arrival_times_to_state,
)
from pyfireca.behavior.crown import CruzCrownFireModel, CruzCrownInputs
from pyfireca.behavior.fbp import FBPComputation, FBPInputs, FBPModel
from pyfireca.behavior.fbp_directional import HomogeneousFBPDirectionalSpreadRate
from pyfireca.behavior.fbp_landscape import build_static_raster_fbp_arrival_solver
from pyfireca.behavior.fbp_layers import FBPRasterLayerNames, StaticRasterFBPInputsProvider
from pyfireca.behavior.fbp_spatial import StaticSpatialFBPDirectionalSpreadRate
from pyfireca.behavior.rothermel_landscape import build_static_raster_rothermel_arrival_solver
from pyfireca.config import StaticRasterInputPaths, StaticRunConfig, load_static_run_config
from pyfireca.data import LandscapeInput
from pyfireca.edge_coupling import HalfCellInterfaceDirectionalSpreadRate
from pyfireca.fbp_config import (
    StaticFBPRasterInputPaths,
    StaticFBPRunConfig,
    load_static_fbp_run_config,
)
from pyfireca.fbp_simulator import StaticFBPSimulationRequest, run_static_fbp_simulation
from pyfireca.fbp_workflow import run_static_fbp_config, validate_static_fbp_run
from pyfireca.grid import RasterGrid
from pyfireca.ignition import IgnitionEvent, build_ignition_times
from pyfireca.neighborhood import MooreNeighborhood, VonNeumannNeighborhood
from pyfireca.outputs import (
    StaticSimulationOutputPaths,
    terminal_state_from_result,
    write_burned_perimeter_geojson,
    write_static_simulation_outputs,
)
from pyfireca.rules import NeighborIgnitionRule
from pyfireca.run_config import load_run_config, run_config, validate_run_config
from pyfireca.simulation import Simulation
from pyfireca.simulator import (
    StaticWildfireSimulationRequest,
    StaticWildfireSimulationResult,
    run_static_wildfire_simulation,
)
from pyfireca.state import FireState
from pyfireca.workflow import StaticRunArtifacts, run_static_config, validate_static_run

__all__ = [
    "ConstantDirectionalSpreadRate",
    "CruzCrownFireModel",
    "CruzCrownInputs",
    "DirectionalSpreadRateProvider",
    "FBPComputation",
    "FBPInputs",
    "FBPModel",
    "FBPRasterLayerNames",
    "FireState",
    "HalfCellInterfaceDirectionalSpreadRate",
    "HomogeneousFBPDirectionalSpreadRate",
    "IgnitionEvent",
    "LandscapeInput",
    "MooreNeighborhood",
    "NeighborIgnitionRule",
    "RasterGrid",
    "Simulation",
    "StaticArrivalTimeSolver",
    "StaticFBPRasterInputPaths",
    "StaticFBPRunConfig",
    "StaticFBPSimulationRequest",
    "StaticRasterFBPInputsProvider",
    "StaticRasterInputPaths",
    "StaticRunArtifacts",
    "StaticRunConfig",
    "StaticSimulationOutputPaths",
    "StaticSpatialFBPDirectionalSpreadRate",
    "StaticWildfireSimulationRequest",
    "StaticWildfireSimulationResult",
    "VonNeumannNeighborhood",
    "arrival_times_to_state",
    "build_ignition_times",
    "build_static_raster_fbp_arrival_solver",
    "build_static_raster_rothermel_arrival_solver",
    "load_run_config",
    "load_static_fbp_run_config",
    "load_static_run_config",
    "run_config",
    "run_static_config",
    "run_static_fbp_config",
    "run_static_fbp_simulation",
    "run_static_wildfire_simulation",
    "terminal_state_from_result",
    "validate_run_config",
    "validate_static_fbp_run",
    "validate_static_run",
    "write_burned_perimeter_geojson",
    "write_static_simulation_outputs",
]

__version__ = "0.1.0a0"
